package com.example.doit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.doit.model.ViecCanLam;

import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;

public class AddNewActivity extends AppCompatActivity {
    Database database;
    Button themVCL;
    TextView lickVCL, gioVCL, nhacNhoVCL, doUuTienVCL;
    EditText chiTietVCL, tenVCL;
    ViecCanLam viecCanLam;
    AlarmManager alarmManager;
    PendingIntent pendingIntent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        database = new Database(this, "doit.sqlite", null, 1);

        viecCanLam = new ViecCanLam();
        tenVCL = findViewById(R.id.tenVCL);
        chiTietVCL = findViewById(R.id.chiTietVCL);
        themVCL = findViewById(R.id.themVCL);
        themVCL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tenVCL.getText().toString().length() == 0) {
                    Toast.makeText(AddNewActivity.this, "Vui lòng điền tên việc cần làm", Toast.LENGTH_SHORT).show();
                    tenVCL.requestFocus();
                }else if(viecCanLam.getGioVCL().length() == 0){
                    Toast.makeText(AddNewActivity.this, "Vui lòng điền giờ", Toast.LENGTH_SHORT).show();
                    gioVCL.requestFocus();
                }else if(viecCanLam.getNgayVCL().length() == 0){
                    Toast.makeText(AddNewActivity.this, "Vui lòng điền ngày", Toast.LENGTH_SHORT).show();
                    lickVCL.requestFocus();
                }else {
                    String[] date = lickVCL.getText().toString().split("-");
                    String[] time = gioVCL.getText().toString().split(":");
                    System.out.println(lickVCL.getText().toString());
                    System.out.println(gioVCL.getText().toString());
                    int id = -1;
                    if(viecCanLam.getNhacNhoVCL().equals("0")){
                        database.QueryData("INSERT INTO vieccanlam values(null,'"+ tenVCL.getText().toString()+
                                "','" + viecCanLam.getNgayVCL() + " "+viecCanLam.getGioVCL() + "','" + viecCanLam.getNhacNhoVCL() +
                                "','" + viecCanLam.getDoUuTienVCL()+ "','" + chiTietVCL.getText().toString() + "'," + '0'+ ")");
                        Cursor temp = database.getData("SELECT * FROM vieccanlam WHERE TenVCL = '"+tenVCL.getText().toString()+
                                "' AND ThoiGianVCL = '" +viecCanLam.getNgayVCL() + " "+viecCanLam.getGioVCL()+"'");
                        while (temp.moveToNext()){
                            id = temp.getInt(0);
                        }
                        setNotification(Integer.parseInt(date[0]), Integer.parseInt(date[1])-1, Integer.parseInt(date[2]),
                                Integer.parseInt(time[0]), Integer.parseInt(time[1]), 0, tenVCL.getText().toString(), id);
                    }else if(viecCanLam.getNhacNhoVCL().equals("1")){
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                            LocalTime time1 = LocalTime.of(Integer.parseInt(time[0]), Integer.parseInt(time[1])); // tạo đối tượng LocalTime với giờ 7:30
                            LocalTime newTime = time1.minusMinutes(60);
                            String[] minTime = String.valueOf(newTime).split(":");
                            setNotification(Integer.parseInt(date[0]), Integer.parseInt(date[1])-1, Integer.parseInt(date[2]),
                                    Integer.parseInt(minTime[0]), Integer.parseInt(minTime[1])+2, 0, tenVCL.getText().toString(), (int) new Date().getTime());
                            setNotification(Integer.parseInt(date[0]), Integer.parseInt(date[1])-1, Integer.parseInt(date[2])-1,
                                    Integer.parseInt(time[0]), Integer.parseInt(time[1]), 0, tenVCL.getText().toString(), id);
                        }
                    }else if(viecCanLam.getNhacNhoVCL().equals("2")){
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                            LocalTime time1 = LocalTime.of(Integer.parseInt(time[0]), Integer.parseInt(time[1])); // tạo đối tượng LocalTime với giờ 7:30
                            LocalTime newTime = time1.minusMinutes(120);
                            String[] minTime = String.valueOf(newTime).split(":");
                            setNotification(Integer.parseInt(date[0]), Integer.parseInt(date[1])-1, Integer.parseInt(date[2]),
                                    Integer.parseInt(minTime[0]), Integer.parseInt(minTime[1])+2, 0, tenVCL.getText().toString(), (int) new Date().getTime());
                            setNotification(Integer.parseInt(date[0]), Integer.parseInt(date[1])-1, Integer.parseInt(date[2])-1,
                                    Integer.parseInt(time[0]), Integer.parseInt(time[1]), 0, tenVCL.getText().toString(), id);
                        }
                    }
                    else{
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                            LocalTime time1 = LocalTime.of(Integer.parseInt(time[0]), Integer.parseInt(time[1])); // tạo đối tượng LocalTime với giờ 7:30
                            LocalTime newTime = time1.minusMinutes(15);
                            String[] minTime = String.valueOf(newTime).split(":");
                            setNotification(Integer.parseInt(date[0]), Integer.parseInt(date[1])-1, Integer.parseInt(date[2]),
                                Integer.parseInt(minTime[0]), Integer.parseInt(minTime[1])+2, 0, tenVCL.getText().toString(), (int) new Date().getTime());
                            setNotification(Integer.parseInt(date[0]), Integer.parseInt(date[1])-1, Integer.parseInt(date[2])-1,
                                    Integer.parseInt(time[0]), Integer.parseInt(time[1]), 0, tenVCL.getText().toString(), id);
                        }
                    }
                    Intent intent = new Intent();
                    setResult(RESULT_OK, intent);
                    finish();
                }
            }
        });

        lickVCL = findViewById(R.id.lichVCL);
        lickVCL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(AddNewActivity.this);
                datePickerDialog.updateDate(2023, 4, 3);
                datePickerDialog.setCanceledOnTouchOutside(false);
                datePickerDialog.setOnDateSetListener(new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        String day = String.valueOf(i2);
                        String mon = String.valueOf(i1+1);
                        if(i1+1 < 10)
                            mon = "0" + (i1+1);
                        if(i2 < 10)
                            day = "0" + i2;
                        lickVCL.setText(i + "-" + mon + "-"+day);
                        viecCanLam.setNgayVCL(i + "-" + mon + "-"+day);
                    }
                });
                datePickerDialog.show();
            }
        });

        gioVCL = findViewById(R.id.gioVCL);
        gioVCL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int hour = 10;
                int minute = 10;
                boolean isMode24H = true;
                TimePickerDialog timePickerDialog = new TimePickerDialog(AddNewActivity.this, new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                String hour = String.valueOf(hourOfDay);
                                String min = String.valueOf(minute);
                                if(hourOfDay < 10)
                                    hour = "0" + hourOfDay;
                                if(minute < 10)
                                    min = "0" + minute;
                                gioVCL.setText(hour+":"+min);
                                viecCanLam.setGioVCL(hour+":"+min+":"+"00");
                            }
                        }, hour, minute, isMode24H);
                timePickerDialog.setCanceledOnTouchOutside(false);
                timePickerDialog.show();
            }
        });

        nhacNhoVCL = findViewById(R.id.nhacNhoVCL);
        viecCanLam.setNhacNhoVCL("0");
        nhacNhoVCL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viecCanLam.setNhacNhoVCL("0");
                String[] listItems = {"15 phút", "30 phút", "1 giờ", "2 giờ"};
                AlertDialog.Builder builder = new AlertDialog.Builder(AddNewActivity.this);
                builder.setItems(listItems, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which){
                            case 0:
                                viecCanLam.setNhacNhoVCL("15");
                                break;
                            case 1:
                                viecCanLam.setNhacNhoVCL("30");
                                break;
                            case 2:
                                viecCanLam.setNhacNhoVCL("1");
                                break;
                            case 3:
                                viecCanLam.setNhacNhoVCL("2");
                                break;
                        }
                        nhacNhoVCL.setText(listItems[which]);
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        doUuTienVCL = findViewById(R.id.doUuTienVCL);
        doUuTienVCL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] listItems = {"Khẩn cấp", "Cao", "Vừa", "Thấp"};
                AlertDialog.Builder builder = new AlertDialog.Builder(AddNewActivity.this);
                builder.setItems(listItems, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which){
                            case 0:
                                viecCanLam.setDoUuTienVCL("4");
                                break;
                            case 1:
                                viecCanLam.setDoUuTienVCL("3");
                                break;
                            case 2:
                                viecCanLam.setDoUuTienVCL("2");
                                break;
                            case 3:
                                viecCanLam.setDoUuTienVCL("1");
                                break;
                            default:
                                viecCanLam.setDoUuTienVCL("1");
                                break;
                        }
                        doUuTienVCL.setText(listItems[which]);
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
    }
    private void setNotification(int year, int month,int day,int hour,int min,int sec, String name, int id){
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.DAY_OF_MONTH, day);
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, min);
        calendar.set(Calendar.SECOND, sec);
        System.out.println(calendar.getTime());
        Intent intent = new Intent(AddNewActivity.this, AlarmReceiver.class);
        intent.putExtra("id",id);
        intent.putExtra("name",name);
        intent.setAction("MyAction");
        alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        pendingIntent = PendingIntent.getBroadcast(AddNewActivity.this, 0,intent, PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}