package com.example.doit;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.MenuItemCompat;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;

import java.util.ArrayList;

public class ListActivity extends AppCompatActivity {
    Database database;
    ListView listActivity;
    ArrayAdapter adapter;
    ArrayList<String> ds;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        database = new Database(this, "doit.sqlite", null ,1);
        listActivity = findViewById(R.id.listActivity);
        ds = new ArrayList<>();
        getData();
        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, ds){
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        System.out.println(ds.get(position));
                        String tg = (ds.get(position).substring(0,19));
                        String ten = (ds.get(position).substring(21));
                        Intent update = new Intent(ListActivity.this, UpdateActivity.class);
                        update.putExtra("ten", ten);
                        update.putExtra("tg", tg);
                        startActivityForResult(update,11);
                    }
                });
                return view;
            }
        };
        listActivity.setAdapter(adapter);
    }
    private void getData(){
        Cursor cursor = database.getData("SELECT * FROM vieccanlam ORDER BY ThoiGianVCL ASC");
        while(cursor.moveToNext()){
            ds.add(cursor.getString(2)+ ": " +cursor.getString(1));
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_search, menu);
        MenuItem searchItem = menu.findItem(R.id.menuSearch);
        final SearchView searchView;
        searchView = (SearchView) MenuItemCompat.getActionView(searchItem);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return true;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                Cursor cursor = database.getData("SELECT TenVCL, ThoiGianVCL FROM vieccanlam where " +
                        "TenVCL like '%"+newText+"%'");
                ds.clear();
                while (cursor.moveToNext()){
                    ds.add(cursor.getString(1) + ": " + cursor.getString(0));
                }
                adapter.notifyDataSetChanged();
                return true;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                return true;
            case R.id.addRecurring:
                Intent add = new Intent(ListActivity.this, AddNewActivity.class);
                startActivityForResult(add, 11);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 11){
            ds.clear();
            getData();
            adapter.notifyDataSetChanged();
        }
    }
}