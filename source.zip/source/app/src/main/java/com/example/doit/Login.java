package com.example.doit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends AppCompatActivity {
    EditText email, pwd;
    TextView forgot;
    Button login, create;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        email = findViewById(R.id.login_email);
        pwd = findViewById(R.id.pass_login);
        forgot = findViewById(R.id.forgot);
        login = findViewById(R.id.login);
        create = findViewById(R.id.createAccount);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(email.getText().toString().length() == 0)
                    email.setHintTextColor(Color.RED);
                else if(pwd.getText().toString().length() < 6)
                    pwd.setHintTextColor(Color.RED);
                else{
                    email.setHintTextColor(Color.BLACK);
                    pwd.setHintTextColor(Color.BLACK);
                    if(email.getText().toString().equals("thanhloi@gmail.com") &&
                    pwd.getText().toString().equals("123456")){
                        setResult(RESULT_OK);
                        finish();
                    }else{
                        Toast.makeText(Login.this, "Email hoặc mật khẩu không đúng", Toast.LENGTH_SHORT).show();
                        email.requestFocus();
                    }
                }
            }
        });

        forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent forgot = new Intent(Login.this, GetCode.class);
                startActivity(forgot);
            }
        });

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent create = new Intent(Login.this, Register.class);
                startActivity(create);
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}