package com.example.doit.model;

public class ViecDinhKy {
    private String tenVDK;
    private String ngayVDK;
    private String gioVDK;
    private String nhacNhoVDK;
    private String lapLaiVDK;
    private String chiTietVDK;

    public ViecDinhKy() {
    }

    public String getTenVDK() {
        return tenVDK;
    }

    public void setTenVDK(String tenVDK) {
        this.tenVDK = tenVDK;
    }

    public String getNgayVDK() {
        return ngayVDK;
    }

    public void setNgayVDK(String ngayVDK) {
        this.ngayVDK = ngayVDK;
    }

    public String getGioVDK() {
        return gioVDK;
    }

    public void setGioVDK(String gioVDK) {
        this.gioVDK = gioVDK;
    }

    public String getNhacNhoVDK() {
        return nhacNhoVDK;
    }

    public void setNhacNhoVDK(String nhacNhoVDK) {
        this.nhacNhoVDK = nhacNhoVDK;
    }

    public String getLapLaiVDK() {
        return lapLaiVDK;
    }

    public void setLapLaiVDK(String lapLaiVDK) {
        this.lapLaiVDK = lapLaiVDK;
    }

    public String getChiTietVDK() {
        return chiTietVDK;
    }

    public void setChiTietVDK(String chiTietVDK) {
        this.chiTietVDK = chiTietVDK;
    }

    @Override
    public String toString() {
        return "ViecDinhKy{" +
                "tenVDK='" + tenVDK + '\'' +
                ", ngayVDK='" + ngayVDK + '\'' +
                ", gioVDK='" + gioVDK + '\'' +
                ", nhacNhoVDK='" + nhacNhoVDK + '\'' +
                ", lapLaiVDK='" + lapLaiVDK + '\'' +
                ", chiTietVDK='" + chiTietVDK + '\'' +
                '}';
    }
}
