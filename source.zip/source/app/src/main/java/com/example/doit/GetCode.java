
package com.example.doit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class GetCode extends AppCompatActivity {
    EditText email;
    Button getCode, createAccount;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_code);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        email = findViewById(R.id.inputEmail);
        getCode = findViewById(R.id.getCode);
        createAccount = findViewById(R.id.createAccount);

        getCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(email.getText().toString().length() == 0){
                    email.setHintTextColor(Color.RED);
                    email.requestFocus();
                }else{
                    email.setHintTextColor(Color.BLACK);
                    Intent getCode = new Intent(GetCode.this, ForgotPassword.class);
                    startActivity(getCode);
                }
            }
        });

        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent create = new Intent(GetCode.this, Register.class);
                startActivity(create);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}