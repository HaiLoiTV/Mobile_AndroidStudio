package com.example.doit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.eazegraph.lib.charts.PieChart;
import org.eazegraph.lib.models.PieModel;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Currency;
import java.util.Date;

public class Statistical extends AppCompatActivity {
    Database database;
    Button week, month;
    TextView title;
    private PieChart pieChart;
    private float i1 = (float) 0.7;
    private float i2 = (float) 0.3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistical);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        database = new Database(this, "doit.sqlite", null, 1);
        pieChart = findViewById(R.id.pie_chart);
        title = findViewById(R.id.title);
        week = findViewById(R.id.week);
        month = findViewById(R.id.month);

        week.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                title.setText("Trong 1 tuần");
                week();
            }
        });

        month.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                title.setText("Trong 1 tháng");
                month();
            }
        });
//        addPieChart(i1,i2);

    }
    private void week(){
        pieChart.clearChart();
        Calendar calendar = Calendar.getInstance();
        Date currentDate = calendar.getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String current = dateFormat.format(currentDate);
        calendar.add(Calendar.DAY_OF_MONTH, -7);
        Date beforeDate = calendar.getTime();
        String beforeDateString = dateFormat.format(beforeDate);
        System.out.println(beforeDateString);
        Cursor temp = database.getData("SELECT * FROM vieccanlam WHERE ThoiGianVCL BETWEEN " +
                "'"+ beforeDateString+" 00:00:00' and '"+ current+" 00:00:00' ");
        int count = temp.getCount();
        float i = 0, j = 0;
        while (temp.moveToNext()){
            if(temp.getString(6).equals("0"))
                j++;
            else
                i++;
        }
        addPieChart(i/count, j/count);
    }

    private void month(){
        pieChart.clearChart();
        Calendar calendar = Calendar.getInstance();
        Date currentDate = calendar.getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String current = dateFormat.format(currentDate);
        calendar.add(Calendar.DAY_OF_MONTH, -30);
        Date beforeDate = calendar.getTime();
        String beforeDateString = dateFormat.format(beforeDate);
        System.out.println(beforeDateString);
        Cursor temp = database.getData("SELECT * FROM vieccanlam WHERE ThoiGianVCL BETWEEN " +
                "'"+ beforeDateString+" 00:00:00' and '"+ current+" 00:00:00' ");
        int count = temp.getCount();
        System.out.println(count);
        float i = 0, j = 0;
        while (temp.moveToNext()){
            if(temp.getString(6).equals("0"))
                j++;
            else
                i++;
        }
        addPieChart(i/count, j/count);
    }
    private void addPieChart(float i, float j) {
        pieChart.addPieSlice(new PieModel("Đã hoàn thành", i, Color.parseColor("#62CDFF")));
        pieChart.addPieSlice(new PieModel("Đã hoàn thành", j, Color.parseColor("#E21818")));
        pieChart.startAnimation();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}