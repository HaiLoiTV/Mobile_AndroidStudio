package com.example.doit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.doit.model.ViecCanLam;

public class UpdateActivity extends AppCompatActivity {
    Database database;
    Button capNhatVCL;
    TextView lickVCL, gioVCL, nhacNhoVCL, doUuTienVCL;
    EditText chiTietVCL, tenVCL;
    ViecCanLam viecCanLam;
    String ten, tg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        viecCanLam = new ViecCanLam();
        database = new Database(this, "doit.sqlite", null, 1);
        capNhatVCL = findViewById(R.id.capNhatVCL);
        lickVCL = findViewById(R.id.lichVCL);
        gioVCL = findViewById(R.id.gioVCL);
        nhacNhoVCL = findViewById(R.id.nhacNhoVCL);
        doUuTienVCL = findViewById(R.id.doUuTienVCL);
        chiTietVCL = findViewById(R.id.chiTietVCL);
        tenVCL = findViewById(R.id.tenVCL);

        Intent update = getIntent();
        ten = update.getStringExtra("ten");
        tg = update.getStringExtra("tg");
        Cursor cursor = database.getData("SELECT NhacNhoVCL, DoUuTienVCL, ChiTietVCL FROM vieccanlam where TenVCL =" +
                "'" + ten +"' and ThoiGianVCL = '" + tg +"'");
        tenVCL.setText(ten);
        lickVCL.setText(tg.split(" ")[0]);
        gioVCL.setText(tg.split(" ")[1].substring(0,5));
        viecCanLam.setNgayVCL(tg.split(" ")[0]);
        viecCanLam.setGioVCL(tg.split(" ")[1]);
        while(cursor.moveToNext()){
            if(cursor.getString(0).equals("0"))
                nhacNhoVCL.setText("Tạo nhắc nhở");
            else if(cursor.getString(0).length() == 1)
                nhacNhoVCL.setText(cursor.getString(0) + " giờ");
            else
                nhacNhoVCL.setText(cursor.getString(0) + " phút");
            switch (cursor.getString(1)){
                case "1":
                    doUuTienVCL.setText("Thấp");
                    break;
                case "2":
                    doUuTienVCL.setText("Vừa");
                    break;
                case "3":
                    doUuTienVCL.setText("Cao");
                    break;
                case "4":
                    doUuTienVCL.setText("Khẩn cấp");
                    break;
            }
            viecCanLam.setNhacNhoVCL(cursor.getString(0));
            viecCanLam.setDoUuTienVCL(cursor.getString(1));
            chiTietVCL.setText(cursor.getString(2));
        }

        lickVCL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(UpdateActivity.this);
                datePickerDialog.updateDate(2023, 4, 3);
                datePickerDialog.setCanceledOnTouchOutside(false);
                datePickerDialog.setOnDateSetListener(new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        String day = String.valueOf(i2);
                        String mon = String.valueOf(i1+1);
                        if(i1+1 < 10)
                            mon = "0" + (i1+1);
                        if(i2 < 10)
                            day = "0" + i2;
                        lickVCL.setText(i + "-" + mon + "-"+day);
                        viecCanLam.setNgayVCL(i + "-" + mon + "-"+day);
                    }
                });
                datePickerDialog.show();
            }
        });

        gioVCL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int hour = 10;
                int minute = 10;
                boolean isMode24H = true;
                TimePickerDialog timePickerDialog = new TimePickerDialog(UpdateActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        String hour = String.valueOf(hourOfDay);
                        String min = String.valueOf(minute);
                        if(hourOfDay < 10)
                            hour = "0" + hourOfDay;
                        if(minute < 10)
                            min = "0" + minute;
                        gioVCL.setText(hour+":"+min);
                        viecCanLam.setGioVCL(hour+":"+min+":"+"00");
                    }
                }, hour, minute, isMode24H);
                timePickerDialog.setCanceledOnTouchOutside(false);
                timePickerDialog.show();
            }
        });

        nhacNhoVCL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] listItems = {"15 phút", "30 phút", "1 giờ", "2 giờ"};
                AlertDialog.Builder builder = new AlertDialog.Builder(UpdateActivity.this);
                builder.setItems(listItems, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which){
                            case 0:
                                viecCanLam.setNhacNhoVCL("15");
                                break;
                            case 1:
                                viecCanLam.setNhacNhoVCL("30");
                                break;
                            case 2:
                                viecCanLam.setNhacNhoVCL("1");
                                break;
                            case 3:
                                viecCanLam.setNhacNhoVCL("2");
                                break;
                            default:
                                viecCanLam.setNhacNhoVCL("0");
                                break;
                        }
                        nhacNhoVCL.setText(listItems[which]);
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        doUuTienVCL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] listItems = {"Khẩn cấp", "Cao", "Vừa", "Thấp"};
                AlertDialog.Builder builder = new AlertDialog.Builder(UpdateActivity.this);
                builder.setItems(listItems, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        System.out.println(which);
                        switch (which){
                            case 0:
                                viecCanLam.setDoUuTienVCL("4");
                                break;
                            case 1:
                                viecCanLam.setDoUuTienVCL("3");
                                break;
                            case 2:
                                viecCanLam.setDoUuTienVCL("2");
                                break;
                            case 3:
                                viecCanLam.setDoUuTienVCL("1");
                                break;
                            default:
                                viecCanLam.setDoUuTienVCL("1");
                                break;
                        }
                        doUuTienVCL.setText(listItems[which]);
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        capNhatVCL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tenVCL.getText().toString().length() == 0) {
                    Toast.makeText(UpdateActivity.this, "Vui lòng điền tên việc cần làm", Toast.LENGTH_SHORT).show();
                    tenVCL.requestFocus();
                }else {
                    database.QueryData("UPDATE vieccanlam " +
                            "SET TenVCL = '"+tenVCL.getText().toString()+"', ThoiGianVCL = '"+viecCanLam.getNgayVCL() + " " + viecCanLam.getGioVCL()+"', NhacNhoVCL = '"+
                            viecCanLam.getNhacNhoVCL()+"', DoUuTienVCL = '"+ viecCanLam.getDoUuTienVCL() +"', ChiTietVCL = '"+
                            chiTietVCL.getText().toString()+"' WHERE TenVCL = '"+ten+"' and ThoiGianVCL = '"+tg+"'");

                    Intent intent = new Intent();
                    setResult(RESULT_OK, intent);
                    finish();
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.delete, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.deleteEvent:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Xóa sự kiện?");
                builder.setMessage("Sự kiện này sẽ bị xóa khỏi ứng dụng");
                builder.setPositiveButton("Xóa", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                database.QueryData("DELETE FROM vieccanlam WHERE TenVCL = '"+ten+"' and " +
                                        "ThoiGianVCL = '"+tg+"'");
                                Intent intent = new Intent();
                                setResult(RESULT_OK,intent);
                                finish();
                            }
                        });
                builder.setNegativeButton("Hủy", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });
                AlertDialog dialog = builder.create();
                dialog.show();
                break;
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}