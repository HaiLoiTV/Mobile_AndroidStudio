package com.example.doit;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.MenuItemCompat;

import android.app.AlarmManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.SearchView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    ListView listEvent;
    ImageButton addEvent;
    ArrayList<String> contentEvent;
    ArrayList<Integer> statusEvent;
    ArrayAdapter<String> adapter;
    Boolean flag = false;
    Database database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //tạo database
        database = new Database(this, "doit.sqlite", null, 1);
        //tạo bảng vieccanlam, ghichu, viecdinhky
        database.QueryData("CREATE TABLE IF NOT EXISTS vieccanlam(id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "TenVCL VARCHAR(200), ThoiGianVCL DATETIME, NhacNhoVCL VARCHAR(50), DoUuTienVCL INTEGER, ChiTietVCL VARCHAR(200), TrangThaiVCL INTEGER )");
//        database.QueryData("INSERT INTO vieccanlam VALUES(null, 'nộp java lab10', '2023-04-29 23:00:00', '15', 1, '',1)");
//        database.QueryData("INSERT INTO vieccanlam VALUES(null, 'nộp mobile lab10', '2023-05-01 23:00:00', '15', 1, '',1)");

        database.QueryData("CREATE TABLE IF NOT EXISTS ghichu(id INTEGER PRIMARY KEY AUTOINCREMENT," +
               "TenGC VARCHAR(200), ChiTietGC VARCHAR(200))");

        database.QueryData("CREATE TABLE IF NOT EXISTS viecdinhky(id INTEGER PRIMARY KEY AUTOINCREMENT," +
               "TenVDK VARCHAR(200), ThoiGianVDK DATETIME, NhacNhoVDK VARCHAR(50), LapLaiVDK INTEGER, ChiTietVDK VARCHAR(200))");

        contentEvent = new ArrayList<>();
        statusEvent = new ArrayList<>();
        showData();

        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(getResources().getDrawable(R.drawable.ic_menu_24));

        addEvent = findViewById(R.id.addEvent);
        addEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Dialog dialog = new Dialog(MainActivity.this);
                dialog.setContentView(R.layout.dialog_custom);
                dialog.setCanceledOnTouchOutside(false);

                //ánh xạ
                TextView viecCanLam = dialog.findViewById(R.id.vieccanlam);
                TextView ghiChu = dialog.findViewById(R.id.ghichu);
                TextView viecDinhKy = dialog.findViewById(R.id.viecdinhky);
                ImageButton huy = dialog.findViewById(R.id.cancelAddEvent);

                huy.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
                viecCanLam.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(MainActivity.this, AddNewActivity.class);
                        startActivityForResult(intent, 1);
                    }
                });
                ghiChu.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(MainActivity.this, AddNewNote.class);
                        startActivity(intent);
                    }
                });
                viecDinhKy.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(MainActivity.this, AddNewRecurring.class);
                        startActivity(intent);
                    }
                });
                dialog.show();
            }
        });

        listEvent = findViewById(R.id.listEvent);
        adapter = new ArrayAdapter<String>(this, R.layout.main_layout, R.id.showEvent,contentEvent){
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                CheckBox tick = view.findViewById(R.id.tick);
                TextView event = view.findViewById(R.id.showEvent);
                if(statusEvent.get(position)== 1){
                    tick.setChecked(true);
                    event.setTextColor(Color.BLACK);
                    event.setBackground(getResources().getDrawable(R.drawable.content_main_add));
                }
                tick.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                        String tg = (event.getText().toString().substring(0,19));
                        String ten = (event.getText().toString().substring(21));
                        if(b) {
                            event.setTextColor(Color.BLACK);
                            event.setBackground(getResources().getDrawable(R.drawable.content_main_add));
                            database.QueryData("UPDATE vieccanlam SET TrangThaiVCL = 1 WHERE " +
                                    "TenVCL = '"+ten+"' AND ThoiGianVCL = '"+tg+"'");
                        }else{
                            event.setTextColor(Color.WHITE);
                            event.setBackground(getResources().getDrawable(R.drawable.content_main));
                            database.QueryData("UPDATE vieccanlam SET TrangThaiVCL = 0 WHERE " +
                                    "TenVCL = '"+ten+"' AND ThoiGianVCL = '"+tg+"'");
                        }
                    }
                });

                event.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String tg = (event.getText().toString().substring(0,19));
                        String ten = (event.getText().toString().substring(21));
                        Intent update = new Intent(MainActivity.this, UpdateActivity.class);
                        update.putExtra("ten", ten);
                        update.putExtra("tg", tg);
                        startActivityForResult(update,11);
                    }
                });
                return view;
            }
        };
        listEvent.setAdapter(adapter);

    }
    private void showData(){
        Calendar calendar = Calendar.getInstance();
        Date currentDate = calendar.getTime();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String current = dateFormat.format(currentDate);

        calendar.add(Calendar.DAY_OF_YEAR, 3);
        Date nextDate = calendar.getTime();
        String nextDateString = dateFormat.format(nextDate);

        Cursor temp = database.getData("SELECT * FROM vieccanlam where ThoiGianVCL between " +
                "'"+ current+" 00:00:00' and '"+ nextDateString+" 23:59:00' ORDER BY ThoiGianVCL ASC ");

        while (temp.moveToNext()){
            statusEvent.add(temp.getInt(6));
            contentEvent.add(temp.getString(2) + ": " + temp.getString(1));
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                ActionBar actionBar = getSupportActionBar();
                View customView = actionBar.getCustomView();
                PopupMenu popupMenu = new PopupMenu(MainActivity.this, customView, Gravity.START);
                popupMenu.getMenuInflater().inflate(R.menu.popup_menu, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        switch (menuItem.getItemId()){
                            case R.id.menuViecDinhKy:
                                Intent viecdinhky = new Intent(MainActivity.this,ListRecurring.class);
                                startActivity(viecdinhky);
                                break;
                            case R.id.menuGhiChu:
                                Intent note = new Intent(MainActivity.this,ListNote.class);
                                startActivity(note);
                                break;
                            case R.id.taikhoan:
                                Intent account = new Intent(MainActivity.this, Account.class);
                                account.putExtra("status", "not");
                                startActivity(account);
                                break;
                            case R.id.thongke:
                                Intent statistical = new Intent(MainActivity.this, Statistical.class);
                                startActivity(statistical);
                                break;
                            case R.id.caidat:
                                Intent setting = new Intent(MainActivity.this, Setting.class);
                                startActivity(setting);
                                break;
                        }
                        return false;
                    }
                });
                popupMenu.show();
                break;
            case R.id.info:
                break;
            case R.id.searchEvent:
                Intent search = new Intent(this, ListActivity.class);
                startActivity(search);
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.menu_main, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId()){

        }

        return super.onContextItemSelected(item);
    }

        @Override
        protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
            super.onActivityResult(requestCode, resultCode, data);
            if(requestCode == 1){
                contentEvent.clear();
                statusEvent.clear();
                showData();
                adapter.notifyDataSetChanged();
            }
            if(requestCode == 11){
                statusEvent.clear();
                contentEvent.clear();
                showData();
                adapter.notifyDataSetChanged();
            }
        }
    }
