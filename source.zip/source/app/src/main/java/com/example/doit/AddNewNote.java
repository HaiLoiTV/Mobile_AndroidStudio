package com.example.doit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddNewNote extends AppCompatActivity {
    Database database;
    EditText tenGC, chiTietGC;
    Button themGC;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_note);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        database = new Database(this, "doit.sqlite", null, 1);
        tenGC = findViewById(R.id.tenGC);
        chiTietGC = findViewById(R.id.chiTietGC);
        themGC = findViewById(R.id.themGC);

        themGC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tenGC.getText().toString().length() == 0){
                    Toast.makeText(AddNewNote.this, "Vui lòng điền tên ghi chi", Toast.LENGTH_SHORT).show();
                }else{
                    database.QueryData("INSERT INTO ghichu VALUES(null,'"+tenGC.getText().toString() +
                            "','"+ chiTietGC.getText().toString()+"')");
                    finish();
                }

            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                fileList();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}