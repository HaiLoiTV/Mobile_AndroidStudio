package com.example.doit;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.MenuItemCompat;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;

import java.util.ArrayList;

public class ListRecurring extends AppCompatActivity {
    ListView dsVDK;
    Database database;
    ArrayAdapter adapter;
    ArrayList<String> ds;
    ArrayList<String> laplai;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_recurring);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        database = new Database(this, "doit.sqlite", null ,1);
        dsVDK = findViewById(R.id.dsViecDinhKy);
        ds = new ArrayList<>();
        laplai = new ArrayList<>();
        showData();
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_2,android.R.id.text1,ds){
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView text1 = view.findViewById(android.R.id.text1);
                TextView text2 = view.findViewById(android.R.id.text2);

                text1.setText(ds.get(position));
                text2.setText(laplai.get(position));
                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String tg = ds.get(position).substring(0,19);
                        String ten = ds.get(position).substring(21);
                        Intent update = new Intent(ListRecurring.this, UpdateRecurring.class);
                        update.putExtra("ten", ten);
                        update.putExtra("tg", tg);
                        startActivityForResult(update,22);
                    }
                });
                return view;
            }
        };
        dsVDK = findViewById(R.id.dsViecDinhKy);
        dsVDK.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_search, menu);
        MenuItem searchItem = menu.findItem(R.id.menuSearch);
        final SearchView searchView;
        searchView = (SearchView) MenuItemCompat.getActionView(searchItem);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return true;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                Cursor cursor = database.getData("SELECT TenVDK, ThoiGianVDK, LapLaiVDK FROM viecdinhky where " +
                        "TenVDK like '%"+newText+"%'");
                ds.clear();
                laplai.clear();
                while (cursor.moveToNext()){
                    ds.add(cursor.getString(1) + ": " + cursor.getString(0));
                    laplai.add("Lặp lại: "+cursor.getString(2) + " tuần");
                }
                adapter.notifyDataSetChanged();
                return true;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                return true;
            case R.id.addRecurring:
                Intent add = new Intent(this, AddNewRecurring.class);
                startActivityForResult(add,2);
        }
        return super.onOptionsItemSelected(item);
    }
    private void showData(){
        Cursor cursor = database.getData("SELECT * FROM viecdinhky");
        while (cursor.moveToNext()){
            ds.add(cursor.getString(2) + ": "+ cursor.getString(1));
            laplai.add("Lặp lại: "+cursor.getString(4) + " tuần");
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 22){
            ds.clear();
            laplai.clear();
            showData();
            adapter.notifyDataSetChanged();
        }
        if(requestCode == 2){
            ds.clear();
            laplai.clear();
            showData();
            adapter.notifyDataSetChanged();
        }
    }
}