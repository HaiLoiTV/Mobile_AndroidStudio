package com.example.doit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ForgotPassword extends AppCompatActivity {
    EditText code, pwd;
    Button reset, createAccount;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        code = findViewById(R.id.txtNhapMa);
        pwd = findViewById(R.id.txtMatKhauMoi);
        reset = findViewById(R.id.reset);
        createAccount = findViewById(R.id.createAccount);

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(code.getText().toString().length() == 0){
                    code.setHintTextColor(Color.RED);
                    code.requestFocus();
                }else if(pwd.getText().toString().length() < 6){
                    Toast.makeText(ForgotPassword.this, "Mật khẩu tối thiểu 6 chữ số", Toast.LENGTH_SHORT).show();
                    pwd.requestFocus();
                }else{
                    code.setHintTextColor(Color.BLACK);
                    if(code.getText().toString().equals("9999")){
                        Intent sucess = new Intent(ForgotPassword.this, Account.class);
                        sucess.putExtra("status","ok");
                        startActivity(sucess);
                    }else{
                        Toast.makeText(ForgotPassword.this, "Mã không đúng", Toast.LENGTH_SHORT).show();
                        code.requestFocus();
                    }
                }
            }
        });

        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent create = new Intent(ForgotPassword.this, Register.class);
                startActivity(create);
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}