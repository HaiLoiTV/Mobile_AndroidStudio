package com.example.doit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.doit.model.ViecCanLam;
import com.example.doit.model.ViecDinhKy;

public class UpdateRecurring extends AppCompatActivity {
    Database database;
    Button capNhatVDK;
    TextView lichVDK, gioVDK, nhacNhoVDK, lapLaiVDK;
    EditText chiTietVDK, tenVDK;
    ViecDinhKy viecDinhKy;
    String ten, tg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_recurring);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        viecDinhKy = new ViecDinhKy();
        database = new Database(this, "doit.sqlite", null, 1);
        capNhatVDK = findViewById(R.id.capNhatVDK);
        lichVDK = findViewById(R.id.lichVDK);
        gioVDK = findViewById(R.id.gioVDK);
        nhacNhoVDK = findViewById(R.id.nhacNhoVDK);
        lapLaiVDK = findViewById(R.id.lapLaiVDK);
        chiTietVDK = findViewById(R.id.chiTietVDK);
        tenVDK = findViewById(R.id.tenVDK);

        Intent update = getIntent();
        ten = update.getStringExtra("ten");
        tg = update.getStringExtra("tg");
        Cursor cursor = database.getData("SELECT NhacNhoVDK, LapLaiVDK, ChiTietVDK FROM viecdinhky where TenVDK =" +
                "'" + ten + "' and ThoiGianVDK = '" + tg + "'");
        tenVDK.setText(ten);
        lichVDK.setText(tg.split(" ")[0]);
        gioVDK.setText(tg.split(" ")[1].substring(0, 5));
        viecDinhKy.setNgayVDK(tg.split(" ")[0]);
        viecDinhKy.setGioVDK(tg.split(" ")[1]);
        while (cursor.moveToNext()) {
            if (cursor.getString(0).equals("0"))
                nhacNhoVDK.setText("Tạo nhắc nhở");
            else if (cursor.getString(0).length() == 1)
                nhacNhoVDK.setText(cursor.getString(0) + " giờ");
            else
                nhacNhoVDK.setText(cursor.getString(0) + " phút");
            lapLaiVDK.setText(cursor.getString(1) + "tuần");
            viecDinhKy.setLapLaiVDK(cursor.getString(1));
            chiTietVDK.setText(cursor.getString(2));
            viecDinhKy.setChiTietVDK(cursor.getString(2));
        }
        setData();
    }
    private void setData(){
        lichVDK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(UpdateRecurring.this);
                datePickerDialog.updateDate(2023, 4, 3);
                datePickerDialog.setCanceledOnTouchOutside(false);
                datePickerDialog.setOnDateSetListener(new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        String day = String.valueOf(i2);
                        String mon = String.valueOf(i1+1);
                        if(i1+1 < 10)
                            mon = "0" + (i1+1);
                        if(i2 < 10)
                            day = "0" + i2;
                        lichVDK.setText(i + "-" + mon + "-"+day);
                        viecDinhKy.setNgayVDK(i + "-" + mon + "-"+day);
                    }
                });
                datePickerDialog.show();
            }
        });

        gioVDK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int hour = 10;
                int minute = 10;
                boolean isMode24H = true;
                TimePickerDialog timePickerDialog = new TimePickerDialog(UpdateRecurring.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        String hour = String.valueOf(hourOfDay);
                        String min = String.valueOf(minute);
                        if(hourOfDay < 10)
                            hour = "0" + hourOfDay;
                        if(minute < 10)
                            min = "0" + minute;
                        gioVDK.setText(hour+":"+min);
                        viecDinhKy.setGioVDK(hour+":"+min+":"+"00");
                    }
                }, hour, minute, isMode24H);
                timePickerDialog.setCanceledOnTouchOutside(false);
                timePickerDialog.show();
            }
        });

        nhacNhoVDK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] listItems = {"15 phút", "30 phút", "1 giờ", "2 giờ"};
                AlertDialog.Builder builder = new AlertDialog.Builder(UpdateRecurring.this);
                builder.setItems(listItems, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which){
                            case 0:
                                viecDinhKy.setNhacNhoVDK("15");
                                break;
                            case 1:
                                viecDinhKy.setNhacNhoVDK("30");
                                break;
                            case 2:
                                viecDinhKy.setNhacNhoVDK("1");
                                break;
                            case 3:
                                viecDinhKy.setNhacNhoVDK("2");
                                break;
                            default:
                                viecDinhKy.setNhacNhoVDK("0");
                                break;
                        }
                        nhacNhoVDK.setText(listItems[which]);
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        lapLaiVDK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] listItems = {"1 tuần", "2 tuần", "3 tuần", "4 tuần"};
                AlertDialog.Builder builder = new AlertDialog.Builder(UpdateRecurring.this);
                builder.setItems(listItems, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which){
                            case 0:
                                viecDinhKy.setLapLaiVDK("1");
                                break;
                            case 1:
                                viecDinhKy.setLapLaiVDK("2");
                                break;
                            case 2:
                                viecDinhKy.setLapLaiVDK("3");
                                break;
                            case 3:
                                viecDinhKy.setLapLaiVDK("4");
                                break;
                            default:
                                viecDinhKy.setLapLaiVDK("1");
                                break;
                        }
                        lapLaiVDK.setText(listItems[which]);
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        capNhatVDK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tenVDK.getText().toString().length() == 0) {
                    Toast.makeText(UpdateRecurring.this, "Vui lòng điền tên việc định kỳ", Toast.LENGTH_SHORT).show();
                    tenVDK.requestFocus();
                }else {
                    database.QueryData("UPDATE viecdinhky " +
                            "SET TenVDK = '"+tenVDK.getText().toString()+"', ThoiGianVDK = '"+viecDinhKy.getNgayVDK() + " " + viecDinhKy.getGioVDK()+"', NhacNhoVDK = '"+
                            viecDinhKy.getNhacNhoVDK()+"', LapLaiVDK = '"+ viecDinhKy.getLapLaiVDK() +"', ChiTietVDK = '"+
                            chiTietVDK.getText().toString()+"' WHERE TenVDK = '"+ten+"' and ThoiGianVDK = '"+tg+"'");
                    Intent intent = new Intent();
                    setResult(RESULT_OK, intent);
                    finish();
                }
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.delete, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.deleteEvent:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Xóa sự kiện?");
                builder.setMessage("Sự kiện này sẽ bị xóa khỏi ứng dụng");
                builder.setPositiveButton("Xóa", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        database.QueryData("DELETE FROM viecdinhky WHERE TenVDK = '"+ten+"' and " +
                                "ThoiGianVDK = '"+tg+"'");
                        Intent intent = new Intent();
                        setResult(RESULT_OK,intent);
                        finish();
                    }
                });
                builder.setNegativeButton("Hủy", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
                break;
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}