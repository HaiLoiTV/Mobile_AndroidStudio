package com.example.doit.model;

public class ViecCanLam {
    private String tenVCL;
    private String ngayVCL;
    private String gioVCL;
    private String nhacNhoVCL;
    private String doUuTienVCL;
    private String trangThaiVCL;
    private String chiTietVCL;

    public ViecCanLam(String tenVCL, String ngayVCL, String nhacNhoVCL, String doUuTienVCL, String trangThaiVCL, String chiTietVCL, String gioVCL) {
        this.tenVCL = tenVCL;
        this.ngayVCL = ngayVCL;
        this.gioVCL = gioVCL;
        this.nhacNhoVCL = nhacNhoVCL;
        this.doUuTienVCL = doUuTienVCL;
        this.trangThaiVCL = trangThaiVCL;
        this.chiTietVCL = chiTietVCL;
    }

    public ViecCanLam() {
        this.tenVCL = "";
        this.ngayVCL = "";
        this.gioVCL = "";
        this.nhacNhoVCL = "";
        this.doUuTienVCL = "";
        this.trangThaiVCL = "";
        this.chiTietVCL = "";
    }

    public String getTenVCL() {
        return tenVCL;
    }

    public void setTenVCL(String tenVCL) {
        this.tenVCL = tenVCL;
    }

    public String getNgayVCL() {
        return ngayVCL;
    }

    public void setNgayVCL(String ngayVCL) {
        this.ngayVCL = ngayVCL;
    }

    public String getGioVCL() {
        return gioVCL;
    }

    public void setGioVCL(String gioVCL) {
        this.gioVCL = gioVCL;
    }

    public String getNhacNhoVCL() {
        return nhacNhoVCL;
    }

    public void setNhacNhoVCL(String nhacNhoVCL) {
        this.nhacNhoVCL = nhacNhoVCL;
    }

    public String getDoUuTienVCL() {
        return doUuTienVCL;
    }

    public void setDoUuTienVCL(String doUuTienVCL) {
        this.doUuTienVCL = doUuTienVCL;
    }

    public String getTrangThaiVCL() {
        return trangThaiVCL;
    }

    public void setTrangThaiVCL(String trangThaiVCL) {
        this.trangThaiVCL = trangThaiVCL;
    }

    public String getChiTietVCL() {
        return chiTietVCL;
    }

    public void setChiTietVCL(String chiTietVCL) {
        this.chiTietVCL = chiTietVCL;
    }

    @Override
    public String toString() {
        return "ViecCanLam{" +
                "tenVCL='" + tenVCL + '\'' +
                ", ngayVCL='" + ngayVCL + '\'' +
                ", gioVCL='" + gioVCL + '\'' +
                ", nhacNhoVCL='" + nhacNhoVCL + '\'' +
                ", doUuTienVCL='" + doUuTienVCL + '\'' +
                ", trangThaiVCL='" + trangThaiVCL + '\'' +
                ", chiTietVCL='" + chiTietVCL + '\'' +
                '}';
    }
}
