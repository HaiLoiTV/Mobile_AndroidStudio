package com.example.doit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateNote extends AppCompatActivity {
    Database database;
    EditText tenGC, chiTietGC;
    Button capNhatGC;
    String id, ten;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_note);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        database = new Database(this, "doit.sqlite", null, 1);
        tenGC = findViewById(R.id.tenGC);
        chiTietGC = findViewById(R.id.chiTietGC);
        capNhatGC = findViewById(R.id.capNhatGC);
        Intent intent = getIntent();
        ten = intent.getStringExtra("ten");
        id = intent.getStringExtra("id");
        tenGC.setText(ten);
        Cursor cursor = database.getData("SELECT * FROM ghichu where id = '"+id+"' and TenGC = '"+ten+"'");
        while(cursor.moveToNext()){
            chiTietGC.setText(cursor.getString(2));
        }

        capNhatGC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tenGC.getText().toString().length() == 0){
                    Toast.makeText(UpdateNote.this, "Vui lòng nhập tên ghi chú", Toast.LENGTH_SHORT).show();
                    tenGC.requestFocus();
                }else{
                    database.QueryData("UPDATE ghichu SET TenGC = '"+tenGC.getText().toString()+"', " +
                            "ChiTietGC = '"+chiTietGC.getText().toString()+"' WHERE id = '"+id+"' and " +
                            "TenGC = '"+ten+"'");
                    setResult(RESULT_OK);
                    finish();
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.delete, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                return true;
            case R.id.deleteEvent:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Xóa ghi chú?");
                builder.setMessage("Ghi chú này sẽ bị xóa khỏi ứng dụng");
                builder.setPositiveButton("Xóa", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        database.QueryData("DELETE FROM ghichu WHERE TenGC = '"+ten+"' and " +
                                "id = '"+id+"'");
                        Intent intent = new Intent();
                        setResult(RESULT_OK,intent);
                        finish();
                    }
                });
                builder.setNegativeButton("Hủy", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}