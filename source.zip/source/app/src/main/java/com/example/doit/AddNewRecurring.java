package com.example.doit;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.doit.model.ViecDinhKy;

import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;

public class AddNewRecurring extends AppCompatActivity {
    AlarmManager alarmManager;
    PendingIntent pendingIntent;
    Database database;
    Button themVDK;
    TextView lichVDK, gioVDK, nhacNhoVDK, lapLaiVDK;
    EditText chiTietVDK, tenVDK;
    ViecDinhKy viecDinhKy;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_recurring);
        setUp();
    }

    private void setUp(){
        database = new Database(this, "doit.sqlite", null, 1);
        themVDK = findViewById(R.id.themVDK);
        lichVDK = findViewById(R.id.lichVDK);
        gioVDK = findViewById(R.id.gioVDK);
        nhacNhoVDK = findViewById(R.id.nhacNhoVDK);
        lapLaiVDK = findViewById(R.id.lapLaiVDK);
        chiTietVDK = findViewById(R.id.chiTietVDK);
        tenVDK = findViewById(R.id.tenVDK);
        viecDinhKy = new ViecDinhKy();
        viecDinhKy.setNhacNhoVDK("0");
        viecDinhKy.setLapLaiVDK("1");
        lichVDK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(AddNewRecurring.this);
                datePickerDialog.updateDate(2023, 4, 3);
                datePickerDialog.setCanceledOnTouchOutside(false);
                datePickerDialog.setOnDateSetListener(new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        String day = String.valueOf(i2);
                        String mon = String.valueOf(i1+1);
                        if(i1+1 < 10)
                            mon = "0" + (i1+1);
                        if(i2 < 10)
                            day = "0" + i2;
                        lichVDK.setText(i + "-" + mon + "-"+day);
                        viecDinhKy.setNgayVDK(i + "-" + mon + "-"+day);
                    }
                });
                datePickerDialog.show();
            }
        });

        gioVDK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int hour = 10;
                int minute = 10;
                boolean isMode24H = true;
                TimePickerDialog timePickerDialog = new TimePickerDialog(AddNewRecurring.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        String hour = String.valueOf(hourOfDay);
                        String min = String.valueOf(minute);
                        if(hourOfDay < 10)
                            hour = "0" + hourOfDay;
                        if(minute < 10)
                            min = "0" + minute;
                        gioVDK.setText(hour+":"+min);
                        viecDinhKy.setGioVDK(hour+":"+min+":"+"00");
                    }
                }, hour, minute, isMode24H);
                timePickerDialog.setCanceledOnTouchOutside(false);
                timePickerDialog.show();
            }
        });

        nhacNhoVDK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] listItems = {"15 phút", "30 phút", "1 giờ", "2 giờ"};
                AlertDialog.Builder builder = new AlertDialog.Builder(AddNewRecurring.this);
                builder.setItems(listItems, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which){
                            case 0:
                                viecDinhKy.setNhacNhoVDK("15");
                                break;
                            case 1:
                                viecDinhKy.setNhacNhoVDK("30");
                                break;
                            case 2:
                                viecDinhKy.setNhacNhoVDK("1");
                                break;
                            case 3:
                                viecDinhKy.setNhacNhoVDK("2");
                                break;
                            default:
                                viecDinhKy.setNhacNhoVDK("0");
                                break;
                        }
                        nhacNhoVDK.setText(listItems[which]);
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        lapLaiVDK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] listItems = {"1 tuần", "2 tuần", "3 tuần", "4 tuần"};
                AlertDialog.Builder builder = new AlertDialog.Builder(AddNewRecurring.this);
                builder.setItems(listItems, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which){
                            case 0:
                                viecDinhKy.setLapLaiVDK("1");
                                break;
                            case 1:
                                viecDinhKy.setLapLaiVDK("2");
                                break;
                            case 2:
                                viecDinhKy.setLapLaiVDK("3");
                                break;
                            case 3:
                                viecDinhKy.setLapLaiVDK("4");
                                break;
                            default:
                                viecDinhKy.setLapLaiVDK("1");
                                break;
                        }
                        lapLaiVDK.setText(listItems[which]);
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        themVDK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tenVDK.getText().toString().length() == 0) {
                    Toast.makeText(AddNewRecurring.this, "Vui lòng điền tên việc định kỳ", Toast.LENGTH_SHORT).show();
                    tenVDK.requestFocus();
                }else if(viecDinhKy.getGioVDK().length() == 0){
                    Toast.makeText(AddNewRecurring.this, "Vui lòng điền giờ", Toast.LENGTH_SHORT).show();
                    gioVDK.requestFocus();
                }else if(viecDinhKy.getNgayVDK().length() == 0){
                    Toast.makeText(AddNewRecurring.this, "Vui lòng điền ngày", Toast.LENGTH_SHORT).show();
                    lichVDK.requestFocus();
                }else {
                    String[] date = lichVDK.getText().toString().split("-");
                    String[] time = gioVDK.getText().toString().split(":");
                    int id = -1;
                    if(viecDinhKy.getNhacNhoVDK().equals("0")){
                        database.QueryData("INSERT INTO viecdinhky values(null,'"+ tenVDK.getText().toString()+
                                "','" + viecDinhKy.getNgayVDK() + " "+viecDinhKy.getGioVDK() + "','" + viecDinhKy.getNhacNhoVDK() +
                                "','" + viecDinhKy.getLapLaiVDK()+ "','" + chiTietVDK.getText().toString() + "')");
                        Cursor temp = database.getData("SELECT * FROM vieccanlam WHERE TenVCL = '"+tenVDK.getText().toString()+
                                "' AND ThoiGianVCL = '" +viecDinhKy.getNgayVDK() + " "+viecDinhKy.getGioVDK()+"'");
                        while (temp.moveToNext()){
                            id = temp.getInt(0);
                        }
                        setNotification(Integer.parseInt(date[0]), Integer.parseInt(date[1])-1, Integer.parseInt(date[2]),
                                Integer.parseInt(time[0]), Integer.parseInt(time[1]), 0, tenVDK.getText().toString(), id);
                    }else if(viecDinhKy.getNhacNhoVDK().equals("1")){
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                            LocalTime time1 = LocalTime.of(Integer.parseInt(time[0]), Integer.parseInt(time[1])); // tạo đối tượng LocalTime với giờ 7:30
                            LocalTime newTime = time1.minusMinutes(60);
                            String[] minTime = String.valueOf(newTime).split(":");
                            setNotification(Integer.parseInt(date[0]), Integer.parseInt(date[1])-1, Integer.parseInt(date[2]),
                                    Integer.parseInt(minTime[0]), Integer.parseInt(minTime[1]), 0, tenVDK.getText().toString(), (int) new Date().getTime());
                            setNotification(Integer.parseInt(date[0]), Integer.parseInt(date[1])-1, Integer.parseInt(date[2])-1,
                                    Integer.parseInt(time[0]), Integer.parseInt(time[1]), 0, tenVDK.getText().toString(), id);
                        }
                    }else if(viecDinhKy.getNhacNhoVDK().equals("2")){
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                            LocalTime time1 = LocalTime.of(Integer.parseInt(time[0]), Integer.parseInt(time[1])); // tạo đối tượng LocalTime với giờ 7:30
                            LocalTime newTime = time1.minusMinutes(120);
                            String[] minTime = String.valueOf(newTime).split(":");
                            setNotification(Integer.parseInt(date[0]), Integer.parseInt(date[1])-1, Integer.parseInt(date[2]),
                                    Integer.parseInt(minTime[0]), Integer.parseInt(minTime[1]), 0, tenVDK.getText().toString(), (int) new Date().getTime());
                            setNotification(Integer.parseInt(date[0]), Integer.parseInt(date[1])-1, Integer.parseInt(date[2])-1,
                                    Integer.parseInt(time[0]), Integer.parseInt(time[1]), 0, tenVDK.getText().toString(), id);
                        }
                    }
                    else{
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                            LocalTime time1 = LocalTime.of(Integer.parseInt(time[0]), Integer.parseInt(time[1])); // tạo đối tượng LocalTime với giờ 7:30
                            LocalTime newTime = time1.minusMinutes(15);
                            String[] minTime = String.valueOf(newTime).split(":");
                            setNotification(Integer.parseInt(date[0]), Integer.parseInt(date[1])-1, Integer.parseInt(date[2]),
                                    Integer.parseInt(minTime[0]), Integer.parseInt(minTime[1]), 0, tenVDK.getText().toString(), (int) new Date().getTime());
                            setNotification(Integer.parseInt(date[0]), Integer.parseInt(date[1])-1, Integer.parseInt(date[2])-1,
                                    Integer.parseInt(time[0]), Integer.parseInt(time[1]), 0, tenVDK.getText().toString(), id);
                        }
                    }
                    setNotificationForVDK(Integer.parseInt(date[0]), Integer.parseInt(date[1])-1, Integer.parseInt(date[2]),
                            Integer.parseInt(time[0]), Integer.parseInt(time[1]), 0, tenVDK.getText().toString(), id, Integer.parseInt(viecDinhKy.getLapLaiVDK()));
                    Intent intent = new Intent();
                    setResult(RESULT_OK, intent);
                    finish();
                }
            }
        });
    }
    private void setNotification(int year, int month,int day,int hour,int min,int sec, String name, int id){
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.DAY_OF_MONTH, day);
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, min);
        calendar.set(Calendar.SECOND, sec);
        Intent intent = new Intent(AddNewRecurring.this, AlarmReceiver.class);
        intent.putExtra("id",id);
        intent.putExtra("name",name);
        intent.setAction("MyAction");
        alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        pendingIntent = PendingIntent.getBroadcast(AddNewRecurring.this, 0,intent, PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
    }

    private void setNotificationForVDK(int year, int month,int day,int hour,int min,int sec, String name, int id, int laplai){
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.DAY_OF_MONTH, day);
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, min);
        calendar.set(Calendar.SECOND, sec);
        calendar.add(Calendar.DAY_OF_MONTH, laplai*7);
        Intent intent = new Intent(AddNewRecurring.this, AlarmReceiver.class);
        intent.putExtra("id",id);
        intent.putExtra("name",name);
        intent.setAction("MyAction");
        alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        pendingIntent = PendingIntent.getBroadcast(AddNewRecurring.this, 0,intent, PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
    }
}