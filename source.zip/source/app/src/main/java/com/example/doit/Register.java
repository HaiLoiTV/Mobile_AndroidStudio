package com.example.doit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends AppCompatActivity {
    EditText fullName, email, pwd;
    Button register, login;
    CheckBox checkBox;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        fullName = findViewById(R.id.fullName);
        email = findViewById(R.id.login_email);
        pwd = findViewById(R.id.pwd);
        register = findViewById(R.id.register);
        login = findViewById(R.id.btnLogin);
        checkBox = findViewById(R.id.check);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(email.getText().toString().length() == 0 || email.getText().toString().indexOf("@gmail") == -1){
                    Toast.makeText(Register.this, "Email không hợp lệ", Toast.LENGTH_SHORT).show();
                    email.requestFocus();
                }else if(fullName.getText().toString().length() == 0){
                    Toast.makeText(Register.this, "Vui lòng nhập tên", Toast.LENGTH_SHORT).show();
                    fullName.requestFocus();
                }else if(pwd.getText().toString().length() < 6) {
                    Toast.makeText(Register.this, "Mật khẩu không hợp lệ", Toast.LENGTH_SHORT).show();
                    pwd.requestFocus();
                }else if(!checkBox.isChecked()){
                    Toast.makeText(Register.this, "Vui lòng chọn đồng ý điều khoản", Toast.LENGTH_SHORT).show();
                }else{
                    Intent success = new Intent(Register.this, Account.class);
                    success.putExtra("status", "ok");
                    startActivity(success);
                }
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent login = new Intent(Register.this, Login.class);
                startActivity(login);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}