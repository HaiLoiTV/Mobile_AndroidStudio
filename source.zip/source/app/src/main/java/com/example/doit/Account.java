package com.example.doit;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class Account extends AppCompatActivity {
    TextView logout, nameUser, email;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        logout = findViewById(R.id.logout);
        email = findViewById(R.id.email);
        nameUser = findViewById(R.id.nameUser);
        Intent account = getIntent();
        String status = account.getStringExtra("status");
        if(status.equals("not"))
            logout.setText("Đăng nhập");
        else{
            logout.setText("Đăng xuất");
            email.setText("thanhloi@gmail.com");
            nameUser.setText("Hai Lợi TV");
        }

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent login = new Intent(Account.this, Login.class);
                startActivityForResult(login, 4);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==4){
            logout.setText("Đăng xuất");
            email.setText("thanhloi@gmail.com");
            nameUser.setText("Hai Lợi TV");
        }
    }
}