package com.example.doit;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import java.util.Date;

public class AlarmReceiver extends BroadcastReceiver {
    final String CHANNEL_ID = "201";
    @Override
    public void onReceive(Context context, Intent intent) {
        String name = intent.getStringExtra("name");
        Intent main = new Intent(context, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, main, 0);
        int id = intent.getIntExtra("id",0);
        if(intent.getAction().equals("MyAction")){
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(context.NOTIFICATION_SERVICE);
            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
                NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Channel 1",NotificationManager.IMPORTANCE_HIGH);
                channel.setDescription("Mieu ta cho kenh 1");
                notificationManager.createNotificationChannel(channel);

            }
            NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                    .setContentTitle("Nhắc nhở")
                    .setContentText(name)
                    .setSmallIcon(R.drawable.baseline_notifications_active_35)
                    .setColor(Color.RED)
                    .setContentIntent(pendingIntent);
            notificationManager.notify(id, builder.build());
        }
    }
}